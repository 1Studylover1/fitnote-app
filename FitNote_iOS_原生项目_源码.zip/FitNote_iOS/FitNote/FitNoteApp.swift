import SwiftUI

@main
struct FitNoteApp: App {
    @StateObject private var store = AppStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .tint(Color.fitGreen)
        }
    }
}
