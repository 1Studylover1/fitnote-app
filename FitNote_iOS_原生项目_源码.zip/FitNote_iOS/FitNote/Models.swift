import Foundation

struct FoodUnit: Codable, Hashable, Identifiable {
    var name: String
    var grams: Double
    var id: String { name }
}

struct FoodItem: Codable, Hashable, Identifiable {
    var id: String
    var name: String
    var category: String
    var emoji: String
    var calories: Double
    var protein: Double
    var carbs: Double
    var fat: Double
    var fiber: Double
    var units: [FoodUnit]
    var defaultUnit: String
    var source: String

    static func sample(_ id: String, _ name: String, _ category: String, _ emoji: String,
                       _ kcal: Double, _ protein: Double, _ carbs: Double, _ fat: Double, _ fiber: Double,
                       _ units: [(String, Double)], _ defaultUnit: String,
                       _ source: String = "常见食物参考值") -> FoodItem {
        FoodItem(id: id, name: name, category: category, emoji: emoji,
                 calories: kcal, protein: protein, carbs: carbs, fat: fat, fiber: fiber,
                 units: units.map { FoodUnit(name: $0.0, grams: $0.1) },
                 defaultUnit: defaultUnit, source: source)
    }
}

enum FoodCatalog {
    static let items: [FoodItem] = [
        .sample("rice", "熟米饭", "主食", "🍚", 116, 2.6, 25.9, 0.3, 0.3, [("碗",150),("小碗",100),("大碗",200),("克",1)], "碗"),
        .sample("oats", "燕麦片（干）", "主食", "🥣", 389, 16.9, 66.3, 6.9, 10.6, [("份",40),("勺",10),("克",1)], "份"),
        .sample("bread", "全麦面包", "主食", "🍞", 250, 12, 43, 4, 7, [("片",30),("克",1)], "片"),
        .sample("potato", "蒸土豆", "主食", "🥔", 87, 1.9, 20.1, 0.1, 1.8, [("个",150),("克",1)], "个"),
        .sample("egg", "鸡蛋（全蛋）", "蛋白质", "🥚", 143, 12.6, 0.7, 9.5, 0, [("个",50),("大个",60),("克",1)], "个"),
        .sample("chicken", "鸡胸肉（熟）", "蛋白质", "🍗", 165, 31, 0, 3.6, 0, [("份",120),("掌心大小",100),("克",1)], "份"),
        .sample("tofu", "北豆腐", "蛋白质", "⬜", 84, 8.1, 4.2, 4.2, 0.5, [("块",100),("克",1)], "块"),
        .sample("salmon", "三文鱼", "蛋白质", "🐟", 208, 20.4, 0, 13.4, 0, [("块",120),("克",1)], "块"),
        .sample("milk", "纯牛奶", "乳制品", "🥛", 62, 3.2, 4.8, 3.3, 0, [("杯",250),("盒",250),("ml",1)], "杯"),
        .sample("yogurt", "原味酸奶", "乳制品", "🥣", 75, 3.5, 8, 3.2, 0, [("杯",200),("小杯",100),("克",1)], "杯"),
        .sample("banana", "香蕉", "水果", "🍌", 89, 1.1, 22.8, 0.3, 2.6, [("根",118),("小根",80),("克",1)], "根"),
        .sample("orange", "橘子", "水果", "🍊", 47, 0.9, 11.8, 0.1, 2.4, [("个",130),("小个",80),("大个",180),("克",1)], "个", "参考值；按去皮可食部分估算"),
        .sample("apple", "苹果", "水果", "🍎", 52, 0.3, 13.8, 0.2, 2.4, [("个",180),("小个",130),("克",1)], "个"),
        .sample("strawberry", "草莓", "水果", "🍓", 32, 0.7, 7.7, 0.3, 2, [("颗",15),("小碗",150),("克",1)], "颗"),
        .sample("almonds", "杏仁", "零食坚果", "🥜", 579, 21.2, 21.6, 49.9, 12.5, [("把",15),("颗",1.2),("克",1)], "把"),
        .sample("broccoli", "西兰花（熟）", "蔬菜", "🥦", 35, 2.4, 7.2, 0.4, 3.3, [("小碗",100),("份",150),("克",1)], "小碗"),
        .sample("tomato", "番茄", "蔬菜", "🍅", 18, 0.9, 3.9, 0.2, 1.2, [("个",120),("克",1)], "个"),
        .sample("cucumber", "黄瓜", "蔬菜", "🥒", 15, 0.7, 3.6, 0.1, 0.5, [("根",200),("克",1)], "根"),
        .sample("dumpling", "水饺（熟）", "主食", "🥟", 200, 8, 28, 6, 1.5, [("个",25),("10个",250),("克",1)], "个", "参考值；馅料差异较大"),
        .sample("coffee", "美式咖啡（无糖）", "饮品", "☕", 2, 0.1, 0, 0, 0, [("杯",250),("中杯",350),("ml",1)], "杯"),
        .sample("ricecake", "米饼", "零食坚果", "🍘", 387, 8, 81, 3, 3, [("片",9),("包",30),("克",1)], "片")
    ]
}

struct FoodLog: Codable, Identifiable {
    var id: UUID = UUID()
    var date: Date
    var foodName: String
    var emoji: String
    var meal: String
    var quantityLabel: String
    var grams: Double
    var calories: Double
    var protein: Double
    var carbs: Double
    var fat: Double
    var fiber: Double
    var note: String = ""
}

struct WorkoutLog: Codable, Identifiable {
    var id: UUID = UUID()
    var date: Date
    var name: String
    var kind: String
    var duration: Int
    var calories: Double?
    var sets: String = ""
    var feeling: String = ""
    var note: String = ""
    var source: String = "manual"
}

struct HealthDay: Codable {
    var steps: Int? = nil
    var activeCalories: Double? = nil
    var waterML: Int? = nil
    var sleepHours: Double? = nil
    var hrv: Double? = nil
    var stress: Int? = nil
    var cycle: String = ""
    var cycleExtra: Double? = nil
    var note: String = ""
}

struct BodyLog: Codable, Identifiable {
    var id: UUID = UUID()
    var date: Date
    var measurements: [String: Double]
    var note: String = ""
}

struct Goals: Codable {
    var goalType: String = "lose"       // lose / gain / maintain
    var targetMode: String = "manual"   // manual / calculated
    var manualCalories: Double = 1800
    var protein: Double = 120
    var carbs: Double = 200
    var fat: Double = 60
    var waterML: Double = 2000
    var deficit: Double = 300
    var surplus: Double = 200
    var cycleAdjustEnabled: Bool = false
    var cycleDefaultExtra: Double = 0
}

struct UserProfile: Codable {
    var nickname: String = ""
    var sex: String = "" // female / male; used only for BMR formula
    var age: Double? = nil
    var heightCM: Double? = nil
    var weightKG: Double? = nil
    var activityFactor: Double = 1.375
    var energyMode: String = "factor" // factor / dynamic
}

struct AppData: Codable {
    var goals = Goals()
    var profile = UserProfile()
    var customFoods: [FoodItem] = []
    var foodLogs: [FoodLog] = []
    var workouts: [WorkoutLog] = []
    var bodyLogs: [BodyLog] = []
    var healthByDate: [String: HealthDay] = [:]
}
