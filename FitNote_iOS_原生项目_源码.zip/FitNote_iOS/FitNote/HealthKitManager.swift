import Foundation
import Combine
import HealthKit

@MainActor
final class HealthKitManager: ObservableObject {
    @Published var statusMessage = "Apple 健康尚未同步"
    @Published var isSyncing = false

    private let healthStore = HKHealthStore()

    var isAvailable: Bool { HKHealthStore.isHealthDataAvailable() }

    func sync(for date: Date) async -> HealthDay? {
        guard isAvailable else {
            statusMessage = "此设备暂不支持 Apple 健康"
            return nil
        }
        isSyncing = true
        defer { isSyncing = false }

        guard
            let steps = HKObjectType.quantityType(forIdentifier: .stepCount),
            let activeEnergy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned),
            let hrvType = HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN),
            let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis)
        else {
            statusMessage = "当前系统缺少所需的健康数据类型"
            return nil
        }

        let readTypes: Set<HKObjectType> = [steps, activeEnergy, hrvType, sleepType]
        do {
            try await healthStore.requestAuthorization(toShare: [], read: readTypes)
            let calendar = Calendar.current
            let dayStart = calendar.startOfDay(for: date)
            let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart) ?? date.addingTimeInterval(86400)

            async let stepValue = sum(for: steps, unit: .count(), start: dayStart, end: dayEnd)
            async let energyValue = sum(for: activeEnergy, unit: .kilocalorie(), start: dayStart, end: dayEnd)
            async let hrvValue = averageHRV(for: hrvType, start: dayStart, end: dayEnd)
            async let sleepValue = sleepHours(for: sleepType, date: date)

            let (stepResult, energyResult, hrvResult, sleepResult) = await (stepValue, energyValue, hrvValue, sleepValue)
            var health = HealthDay()
            health.steps = stepResult.map { Int($0.rounded()) }
            health.activeCalories = energyResult
            health.hrv = hrvResult
            health.sleepHours = sleepResult
            statusMessage = "已读取可用的 Apple 健康数据；没有授权或没有记录的项目会留空。"
            return health
        } catch {
            statusMessage = "同步未完成：请检查 iPhone「健康」权限设置。"
            return nil
        }
    }

    private func sum(for type: HKQuantityType, unit: HKUnit, start: Date, end: Date) async -> Double? {
        await withCheckedContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
            let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, stats, _ in
                continuation.resume(returning: stats?.sumQuantity()?.doubleValue(for: unit))
            }
            healthStore.execute(query)
        }
    }

    private func averageHRV(for type: HKQuantityType, start: Date, end: Date) async -> Double? {
        await withCheckedContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: 30, sortDescriptors: [sort]) { _, samples, _ in
                let values = (samples as? [HKQuantitySample])?.map { $0.quantity.doubleValue(for: .secondUnit(with: .milli)) } ?? []
                guard !values.isEmpty else { continuation.resume(returning: nil); return }
                continuation.resume(returning: values.reduce(0, +) / Double(values.count))
            }
            healthStore.execute(query)
        }
    }

    private func sleepHours(for type: HKCategoryType, date: Date) async -> Double? {
        let calendar = Calendar.current
        let dayStart = calendar.startOfDay(for: date)
        let queryStart = calendar.date(byAdding: .hour, value: -18, to: dayStart) ?? dayStart.addingTimeInterval(-64800)
        let queryEnd = calendar.date(byAdding: .hour, value: 12, to: dayStart) ?? dayStart.addingTimeInterval(43200)
        return await withCheckedContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(withStart: queryStart, end: queryEnd, options: [])
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: [sort]) { _, samples, _ in
                let asleepValues: Set<Int> = [
                    HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,
                    HKCategoryValueSleepAnalysis.asleepCore.rawValue,
                    HKCategoryValueSleepAnalysis.asleepDeep.rawValue,
                    HKCategoryValueSleepAnalysis.asleepREM.rawValue
                ]
                let intervals = (samples as? [HKCategorySample] ?? []).filter { asleepValues.contains($0.value) }
                guard !intervals.isEmpty else { continuation.resume(returning: nil); return }
                let seconds = intervals.reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
                continuation.resume(returning: seconds / 3600)
            }
            healthStore.execute(query)
        }
    }
}
