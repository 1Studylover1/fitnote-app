import Foundation
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    @Published var data: AppData { didSet { persist() } }
    @Published var selectedDate: Date = Date()

    private let fileName = "FitNoteData.json"

    init() {
        if let loaded = Self.loadFromDisk() {
            data = loaded
        } else {
            data = AppData()
        }
    }

    private static func dataURL() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FitNoteData.json")
    }

    private static func loadFromDisk() -> AppData? {
        guard let bytes = try? Data(contentsOf: dataURL()) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(AppData.self, from: bytes)
    }

    private func persist() {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let bytes = try? encoder.encode(data) else { return }
        try? bytes.write(to: Self.dataURL(), options: [.atomic])
    }

    func dayKey(_ date: Date) -> String {
        let f = DateFormatter()
        f.calendar = Calendar.current
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = Calendar.current.timeZone
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }

    func sameDay(_ lhs: Date, _ rhs: Date) -> Bool {
        Calendar.current.isDate(lhs, inSameDayAs: rhs)
    }

    func foods(matching query: String = "", category: String = "全部") -> [FoodItem] {
        let all = FoodCatalog.items + data.customFoods
        return all.filter {
            (category == "全部" || $0.category == category) &&
            (query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) || $0.category.localizedCaseInsensitiveContains(query))
        }
    }

    func foodLogs(on date: Date) -> [FoodLog] {
        data.foodLogs.filter { sameDay($0.date, date) }.sorted { $0.date < $1.date }
    }

    func workouts(on date: Date) -> [WorkoutLog] {
        data.workouts.filter { sameDay($0.date, date) }.sorted { $0.date < $1.date }
    }

    func health(on date: Date) -> HealthDay {
        data.healthByDate[dayKey(date)] ?? HealthDay()
    }

    func calories(on date: Date) -> Double {
        foodLogs(on: date).reduce(0) { $0 + $1.calories }
    }

    func workoutCalories(on date: Date) -> Double {
        workouts(on: date).reduce(0) { $0 + ($1.calories ?? 0) }
    }

    func workoutMinutes(on date: Date) -> Int {
        workouts(on: date).reduce(0) { $0 + $1.duration }
    }

    func macros(on date: Date) -> (protein: Double, carbs: Double, fat: Double) {
        let logs = foodLogs(on: date)
        return (logs.reduce(0) { $0 + $1.protein },
                logs.reduce(0) { $0 + $1.carbs },
                logs.reduce(0) { $0 + $1.fat })
    }

    func bmr() -> Double? {
        guard let age = data.profile.age, let height = data.profile.heightCM,
              let weight = data.profile.weightKG, !data.profile.sex.isEmpty else { return nil }
        return 10 * weight + 6.25 * height - 5 * age + (data.profile.sex == "male" ? 5 : -161)
    }

    func tdee(on date: Date) -> Double? {
        guard let base = bmr() else { return nil }
        if data.profile.energyMode == "dynamic" {
            let active = health(on: date).activeCalories ?? workoutCalories(on: date)
            return base * 1.2 + active
        }
        return base * data.profile.activityFactor
    }

    func target(on date: Date) -> Double {
        let goals = data.goals
        var result = goals.manualCalories
        if goals.targetMode == "calculated", let tdee = tdee(on: date) {
            switch goals.goalType {
            case "lose": result = tdee - goals.deficit
            case "gain": result = tdee + goals.surplus
            default: result = tdee
            }
        }
        if goals.cycleAdjustEnabled {
            result += health(on: date).cycleExtra ?? goals.cycleDefaultExtra
        }
        return max(0, result)
    }

    func addFood(food: FoodItem, quantity: Double, unit: FoodUnit, gramsOverride: Double?,
                 meal: String, note: String, date: Date) {
        let grams = max(0, gramsOverride ?? quantity * unit.grams)
        guard grams > 0 else { return }
        let scale = grams / 100
        let log = FoodLog(date: date, foodName: food.name, emoji: food.emoji, meal: meal,
                          quantityLabel: gramsOverride != nil
                            ? "\(grams.formatted(.number.precision(.fractionLength(0...1)))) g"
                            : "\(quantity.formatted(.number.precision(.fractionLength(0...1)))) \(unit.name)（约 \(grams.formatted(.number.precision(.fractionLength(0...1)))) g）",
                          grams: grams, calories: food.calories * scale, protein: food.protein * scale,
                          carbs: food.carbs * scale, fat: food.fat * scale, fiber: food.fiber * scale, note: note)
        var copy = data
        copy.foodLogs.append(log)
        data = copy
    }

    func deleteFood(_ id: UUID) {
        var copy = data
        copy.foodLogs.removeAll { $0.id == id }
        data = copy
    }

    func addCustomFood(_ food: FoodItem) {
        var copy = data
        copy.customFoods.append(food)
        data = copy
    }

    func addWorkout(_ workout: WorkoutLog) {
        var copy = data
        copy.workouts.append(workout)
        data = copy
    }

    func deleteWorkout(_ id: UUID) {
        var copy = data
        copy.workouts.removeAll { $0.id == id }
        data = copy
    }

    func saveHealth(_ health: HealthDay, for date: Date) {
        var copy = data
        copy.healthByDate[dayKey(date)] = health
        data = copy
    }

    func saveGoals(_ goals: Goals) {
        var copy = data
        copy.goals = goals
        data = copy
    }

    func saveProfile(_ profile: UserProfile) {
        var copy = data
        copy.profile = profile
        data = copy
    }

    func addBodyLog(_ log: BodyLog) {
        var copy = data
        copy.bodyLogs.append(log)
        if let weight = log.measurements["体重"] { copy.profile.weightKG = weight }
        data = copy
    }

    func deleteBodyLog(_ id: UUID) {
        var copy = data
        copy.bodyLogs.removeAll { $0.id == id }
        data = copy
    }

    func exportBackup() -> URL? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let bytes = try? encoder.encode(data) else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("FitNote-backup-\(dayKey(Date())).json")
        do {
            try bytes.write(to: url, options: [.atomic])
            return url
        } catch {
            return nil
        }
    }

    func importBackup(from url: URL) throws {
        let bytes = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let imported = try decoder.decode(AppData.self, from: bytes)
        data = imported
    }

    func clearAllData() {
        data = AppData()
    }
}
