import SwiftUI
import UniformTypeIdentifiers

extension Color {
    static let fitGreen = Color(red: 0.36, green: 0.51, blue: 0.39)
    static let fitDarkGreen = Color(red: 0.25, green: 0.39, blue: 0.28)
    static let fitCream = Color(red: 0.98, green: 0.975, blue: 0.94)
    static let fitMint = Color(red: 0.91, green: 0.95, blue: 0.89)
    static let fitPink = Color(red: 0.97, green: 0.89, blue: 0.90)
    static let fitPeach = Color(red: 0.98, green: 0.92, blue: 0.85)
    static let fitBlue = Color(red: 0.89, green: 0.94, blue: 0.96)
    static let fitLavender = Color(red: 0.93, green: 0.91, blue: 0.96)
    static let fitInk = Color(red: 0.19, green: 0.22, blue: 0.18)
    static let fitMuted = Color(red: 0.50, green: 0.54, blue: 0.48)
}

private func kcal(_ value: Double) -> String { Int(value.rounded()).formatted() }
private func dayText(_ date: Date) -> String { date.formatted(.dateTime.year().month().day()) }

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack { HomeView() }
                .tabItem { Label("首页", systemImage: "house.fill") }
            NavigationStack { FoodView() }
                .tabItem { Label("饮食", systemImage: "leaf.fill") }
            NavigationStack { WorkoutView() }
                .tabItem { Label("运动", systemImage: "dumbbell.fill") }
            NavigationStack { CalendarView() }
                .tabItem { Label("月历", systemImage: "calendar") }
            NavigationStack { ProfileView() }
                .tabItem { Label("我的", systemImage: "person.crop.circle.fill") }
        }
        .toolbarBackground(.visible, for: .tabBar)
        .toolbarBackground(Color.fitCream, for: .tabBar)
    }
}

struct SoftCard<Content: View>: View {
    var title: String? = nil
    var subtitle: String? = nil
    let content: Content

    init(title: String? = nil, subtitle: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            if let title {
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.headline).foregroundStyle(Color.fitInk)
                    if let subtitle {
                        Text(subtitle).font(.caption).foregroundStyle(Color.fitMuted)
                    }
                }
            }
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.white, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.fitGreen.opacity(0.10), lineWidth: 1))
        .shadow(color: Color.fitDarkGreen.opacity(0.04), radius: 12, y: 5)
    }
}

struct MetricCard: View {
    var emoji: String
    var title: String
    var value: String
    var unit: String
    var foot: String
    var tint: Color
    var progress: Double? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Text(emoji)
                Text(title).font(.caption.weight(.semibold)).foregroundStyle(Color.fitMuted)
            }
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(value).font(.system(size: 25, weight: .bold, design: .rounded)).foregroundStyle(Color.fitInk).minimumScaleFactor(0.7).lineLimit(1)
                Text(unit).font(.caption2.weight(.medium)).foregroundStyle(Color.fitMuted)
            }
            Text(foot).font(.caption2).foregroundStyle(Color.fitMuted).lineLimit(2)
            if let progress {
                ProgressView(value: min(1, max(0, progress))).tint(Color.fitGreen)
            }
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(tint, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct HomeView: View {
    @EnvironmentObject private var store: AppStore

    private var consumed: Double { store.calories(on: store.selectedDate) }
    private var target: Double { store.target(on: store.selectedDate) }
    private var balance: Double { target - consumed }
    private var health: HealthDay { store.health(on: store.selectedDate) }
    private var macros: (protein: Double, carbs: Double, fat: Double) { store.macros(on: store.selectedDate) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 12) {
                    Image("LeopardMascot").resizable().scaledToFill()
                        .frame(width: 66, height: 66).clipShape(RoundedRectangle(cornerRadius: 22))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FitNote").font(.title2.bold()).foregroundStyle(Color.fitInk)
                        Text("好好吃饭，好好生活 🌷").font(.subheadline).foregroundStyle(Color.fitMuted)
                        Text("每一点努力都值得被记录").font(.caption).foregroundStyle(Color.fitGreen)
                    }
                    Spacer(minLength: 0)
                }
                DatePicker("查看日期", selection: $store.selectedDate, displayedComponents: .date)
                    .datePickerStyle(.compact)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(.white, in: RoundedRectangle(cornerRadius: 14))

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    MetricCard(emoji: "🍚", title: "今日摄入", value: kcal(consumed), unit: "kcal",
                               foot: "目标 \(kcal(target)) kcal", tint: Color.fitMint, progress: consumed / max(1, target))
                    MetricCard(emoji: balance >= 0 ? "🌼" : "🌸", title: balance >= 0 ? "剩余热量" : "超过目标",
                               value: kcal(abs(balance)), unit: "kcal",
                               foot: balance >= 0 ? "留有一点弹性空间" : "明天继续照顾好自己", tint: Color.fitPeach)
                    MetricCard(emoji: "🏋️", title: "运动时长", value: "\(store.workoutMinutes(on: store.selectedDate))", unit: "分钟",
                               foot: "\(store.workouts(on: store.selectedDate).count) 条运动记录", tint: Color.fitBlue)
                    MetricCard(emoji: "💧", title: "今日饮水", value: "\(health.waterML ?? 0)", unit: "ml",
                               foot: "参考目标 \(Int(store.data.goals.waterML)) ml", tint: Color.fitPink,
                               progress: Double(health.waterML ?? 0) / max(1, store.data.goals.waterML))
                }

                SoftCard(title: "🌈 今日营养彩虹", subtitle: "参考目标可以调整，不需要追求每一天都完美。") {
                    MacroLine(name: "蛋白质", value: macros.protein, goal: store.data.goals.protein, color: Color(red: 0.82, green: 0.57, blue: 0.43))
                    MacroLine(name: "碳水", value: macros.carbs, goal: store.data.goals.carbs, color: Color(red: 0.80, green: 0.68, blue: 0.36))
                    MacroLine(name: "脂肪", value: macros.fat, goal: store.data.goals.fat, color: Color.fitGreen)
                }

                SoftCard(title: "💧 喝点水吧", subtitle: "点一下就记一杯。") {
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        Text("\(health.waterML ?? 0)").font(.system(size: 30, weight: .bold, design: .rounded))
                        Text("/ \(Int(store.data.goals.waterML)) ml").font(.caption).foregroundStyle(Color.fitMuted)
                    }
                    HStack(spacing: 8) {
                        ForEach([150, 250, 500], id: \.self) { amount in
                            Button("+\(amount) ml") {
                                var updated = health
                                updated.waterML = (updated.waterML ?? 0) + amount
                                store.saveHealth(updated, for: store.selectedDate)
                            }
                            .buttonStyle(.bordered)
                            .tint(Color.fitGreen)
                        }
                    }
                }

                SoftCard(title: "🍱 今天吃了什么", subtitle: "\(dayText(store.selectedDate))") {
                    let logs = store.foodLogs(on: store.selectedDate).reversed()
                    if logs.isEmpty {
                        EmptyHint(emoji: "🍓", text: "还没有饮食记录，去饮食页添加第一餐吧。")
                    } else {
                        ForEach(Array(logs.prefix(5))) { log in
                            HStack(spacing: 10) {
                                Text(log.emoji).font(.title3).frame(width: 38, height: 38).background(Color.fitPeach, in: RoundedRectangle(cornerRadius: 12))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(log.foodName).font(.subheadline.weight(.semibold))
                                    Text("\(log.meal) · \(log.quantityLabel)").font(.caption).foregroundStyle(Color.fitMuted)
                                }
                                Spacer()
                                Text("\(kcal(log.calories)) kcal").font(.caption.weight(.semibold))
                            }
                            .padding(.vertical, 3)
                        }
                    }
                }

                SoftCard(title: "🏋️ 今天动了什么", subtitle: "训练、散步和拉伸都值得记录。") {
                    let logs = store.workouts(on: store.selectedDate).reversed()
                    if logs.isEmpty {
                        EmptyHint(emoji: "🌿", text: "休息日也很好。想记录训练时，去运动页写下今天练了什么。")
                    } else {
                        ForEach(Array(logs.prefix(5))) { log in
                            HStack(spacing: 10) {
                                Text("🏋️").font(.title3).frame(width: 38, height: 38).background(Color.fitMint, in: RoundedRectangle(cornerRadius: 12))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(log.name).font(.subheadline.weight(.semibold))
                                    Text("\(log.kind) · \(log.duration) 分钟").font(.caption).foregroundStyle(Color.fitMuted)
                                }
                                Spacer()
                                Text(log.calories.map { "\(kcal($0)) kcal" } ?? "未填写").font(.caption.weight(.semibold))
                            }
                        }
                    }
                }

                SoftCard(title: "🌙 身体小记", subtitle: "数据来自手动记录或你授权的 Apple 健康同步。") {
                    HStack(spacing: 10) {
                        MiniHealth(emoji: "👣", title: "步数", value: health.steps.map { "\($0.formatted())" } ?? "—")
                        MiniHealth(emoji: "🌙", title: "睡眠", value: health.sleepHours.map { String(format: "%.1f h", $0) } ?? "—")
                        MiniHealth(emoji: "💓", title: "HRV", value: health.hrv.map { String(format: "%.0f ms", $0) } ?? "—")
                    }
                    Text("压力感受由你手动记录；Apple 健康不提供一个通用的“实时压力值”。").font(.caption2).foregroundStyle(Color.fitMuted)
                }
            }
            .padding(16)
        }
        .background(Color.fitCream.ignoresSafeArea())
        .navigationBarHidden(true)
    }
}

struct MacroLine: View {
    var name: String
    var value: Double
    var goal: Double
    var color: Color

    var body: some View {
        VStack(spacing: 5) {
            HStack {
                Text(name).font(.caption.weight(.semibold))
                Spacer()
                Text("\(value.formatted(.number.precision(.fractionLength(0...1)))) / \(Int(goal)) g")
                    .font(.caption).foregroundStyle(Color.fitMuted)
            }
            ProgressView(value: min(1, value / max(1, goal))).tint(color)
        }
    }
}

struct MiniHealth: View {
    var emoji: String
    var title: String
    var value: String
    var body: some View {
        VStack(spacing: 5) {
            Text(emoji).font(.title3)
            Text(value).font(.subheadline.weight(.bold)).lineLimit(1).minimumScaleFactor(0.7)
            Text(title).font(.caption2).foregroundStyle(Color.fitMuted)
        }
        .frame(maxWidth: .infinity).padding(10)
        .background(Color.fitCream, in: RoundedRectangle(cornerRadius: 15))
    }
}

struct EmptyHint: View {
    var emoji: String
    var text: String
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Text(emoji).font(.title2)
            Text(text).font(.caption).foregroundStyle(Color.fitMuted)
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.fitCream, in: RoundedRectangle(cornerRadius: 14))
    }
}

enum FoodSheet: Identifiable {
    case add(FoodItem)
    case custom
    var id: String {
        switch self {
        case .add(let food): return "add-\(food.id)"
        case .custom: return "custom-food"
        }
    }
}

struct FoodView: View {
    @EnvironmentObject private var store: AppStore
    @State private var query = ""
    @State private var category = "全部"
    @State private var activeSheet: FoodSheet?

    private var categories: [String] {
        ["全部"] + Array(Set((FoodCatalog.items + store.data.customFoods).map(\.category))).sorted()
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("吃得开心，也记得清楚 🍓").font(.title2.bold())
                    Text("按个、按片、按碗，怎么顺手怎么记；也支持把零食和大餐单独标记出来。").font(.caption).foregroundStyle(Color.fitMuted)
                }
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(Color.fitMuted)
                    TextField("搜索橘子、米饭、酸奶……", text: $query)
                }
                .padding(12).background(.white, in: RoundedRectangle(cornerRadius: 13))

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(categories, id: \.self) { item in
                            Button(item) { category = item }
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 13).padding(.vertical, 8)
                                .background(category == item ? Color.fitGreen : .white, in: Capsule())
                                .foregroundStyle(category == item ? .white : Color.fitMuted)
                        }
                    }
                }

                SoftCard(title: "🥝 免费食物参考库", subtitle: "内置常见食物参考值；包装食品请优先使用实物营养标签。") {
                    ForEach(store.foods(matching: query, category: category)) { food in
                        HStack(spacing: 11) {
                            Text(food.emoji).font(.title2).frame(width: 45, height: 45).background(Color.fitMint, in: RoundedRectangle(cornerRadius: 14))
                            VStack(alignment: .leading, spacing: 3) {
                                Text(food.name).font(.subheadline.weight(.semibold))
                                Text("\(kcal(food.calories)) kcal / 100 g · 常用单位：\(food.defaultUnit)")
                                    .font(.caption2).foregroundStyle(Color.fitMuted)
                                Text(food.source).font(.caption2).foregroundStyle(Color.fitMuted).lineLimit(1)
                            }
                            Spacer(minLength: 3)
                            Button("＋ 记录") { activeSheet = .add(food) }
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 10).padding(.vertical, 8)
                                .background(Color.fitMint, in: Capsule())
                                .foregroundStyle(Color.fitDarkGreen)
                        }
                        .padding(.vertical, 4)
                    }
                }

                SoftCard(title: "📦 自己的包装食品", subtitle: "根据营养成分表录入一次，下次只需要调整份量。") {
                    Button { activeSheet = .custom } label: {
                        Label("添加包装食品 / 自定义食物", systemImage: "plus.circle.fill")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent).tint(Color.fitGreen)
                }

                SoftCard(title: "🧺 \(dayText(store.selectedDate)) 饮食记录", subtitle: "当天合计 \(kcal(store.calories(on: store.selectedDate))) kcal") {
                    let logs = store.foodLogs(on: store.selectedDate).reversed()
                    if logs.isEmpty {
                        EmptyHint(emoji: "🍱", text: "还没有记录。选择上面的食物即可添加。")
                    } else {
                        ForEach(Array(logs)) { log in
                            HStack(spacing: 10) {
                                Text(log.emoji).font(.title3).frame(width: 38, height: 38).background(Color.fitPeach, in: RoundedRectangle(cornerRadius: 12))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(log.foodName).font(.subheadline.weight(.semibold))
                                    Text("\(log.meal) · \(log.quantityLabel)\(log.note.isEmpty ? "" : " · \(log.note)")")
                                        .font(.caption).foregroundStyle(Color.fitMuted)
                                    Text("蛋白质 \(log.protein, specifier: "%.1f") g · 碳水 \(log.carbs, specifier: "%.1f") g · 脂肪 \(log.fat, specifier: "%.1f") g")
                                        .font(.caption2).foregroundStyle(Color.fitMuted)
                                }
                                Spacer(minLength: 0)
                                VStack(alignment: .trailing, spacing: 4) {
                                    Text("\(kcal(log.calories)) kcal").font(.caption.weight(.bold))
                                    Button(role: .destructive) { store.deleteFood(log.id) } label: {
                                        Image(systemName: "trash").font(.caption)
                                    }
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .padding(16)
        }
        .background(Color.fitCream.ignoresSafeArea())
        .navigationTitle("饮食记录")
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .add(let food): AddFoodSheet(food: food)
            case .custom: CustomFoodSheet()
            }
        }
    }
}

struct AddFoodSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let food: FoodItem
    @State private var meal = "午餐"
    @State private var unitName = ""
    @State private var quantity = "1"
    @State private var exactGrams = ""
    @State private var note = ""

    private var unit: FoodUnit { food.units.first(where: { $0.name == unitName }) ?? food.units.first ?? FoodUnit(name: "克", grams: 1) }
    private var grams: Double { Double(exactGrams) ?? ((Double(quantity) ?? 0) * unit.grams) }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 12) {
                        Text(food.emoji).font(.largeTitle)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(food.name).font(.headline)
                            Text("\(kcal(food.calories)) kcal / 100 g").font(.caption).foregroundStyle(Color.fitMuted)
                        }
                    }
                }
                Section("本次份量") {
                    Picker("餐次", selection: $meal) {
                        ForEach(["早餐", "午餐", "晚餐", "加餐", "零食", "大餐"], id: \.self) { Text($0) }
                    }
                    Picker("计量单位", selection: $unitName) {
                        ForEach(food.units) { unit in
                            Text("\(unit.name)（约 \(Int(unit.grams)) g）").tag(unit.name)
                        }
                    }
                    TextField("数量", text: $quantity).keyboardType(.decimalPad)
                    TextField("实际可食重量 g（可选）", text: $exactGrams).keyboardType(.decimalPad)
                    TextField("备注（可选）", text: $note)
                }
                Section("营养估算") {
                    LabeledContent("可食重量", value: String(format: "%.1f g", max(0, grams)))
                    LabeledContent("热量", value: "\(kcal(food.calories * max(0, grams) / 100)) kcal")
                    LabeledContent("蛋白质", value: String(format: "%.1f g", food.protein * max(0, grams) / 100))
                    LabeledContent("碳水", value: String(format: "%.1f g", food.carbs * max(0, grams) / 100))
                    LabeledContent("脂肪", value: String(format: "%.1f g", food.fat * max(0, grams) / 100))
                }
                Section {
                    Text("这些是参考估算值。橘子等食物按去皮后的可食部分估算；品牌、做法和实际份量会带来差异。")
                        .font(.caption).foregroundStyle(Color.fitMuted)
                }
            }
            .navigationTitle("记录这份食物")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        guard grams > 0 else { return }
                        store.addFood(food: food, quantity: Double(quantity) ?? 1, unit: unit,
                                      gramsOverride: Double(exactGrams), meal: meal, note: note,
                                      date: store.selectedDate)
                        dismiss()
                    }
                    .fontWeight(.bold)
                }
            }
            .onAppear { unitName = food.defaultUnit }
        }
        .tint(Color.fitGreen)
    }
}

struct CustomFoodSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var category = "包装食品"
    @State private var basis = "100"
    @State private var serving = "200"
    @State private var energy = ""
    @State private var energyUnit = "kJ"
    @State private var protein = "0"
    @State private var carbs = "0"
    @State private var fat = "0"
    @State private var fiber = "0"
    @State private var unitName = "份"
    @State private var unitWeight = "200"

    var body: some View {
        NavigationStack {
            Form {
                Section("食品信息") {
                    TextField("食品名称", text: $name)
                    Picker("分类", selection: $category) {
                        ForEach(["包装食品", "乳制品", "零食坚果", "饮品", "主食", "其他"], id: \.self) { Text($0) }
                    }
                    Picker("营养标签标注", selection: $basis) {
                        Text("每 100 g / ml").tag("100")
                        Text("每份 / 每瓶").tag("serving")
                    }
                    if basis == "serving" {
                        TextField("每份净含量 g / ml", text: $serving).keyboardType(.decimalPad)
                    }
                }
                Section("营养成分表") {
                    HStack {
                        TextField("能量数值", text: $energy).keyboardType(.decimalPad)
                        Picker("单位", selection: $energyUnit) {
                            Text("kJ").tag("kJ")
                            Text("kcal").tag("kcal")
                        }.pickerStyle(.segmented).frame(width: 120)
                    }
                    TextField("蛋白质 g", text: $protein).keyboardType(.decimalPad)
                    TextField("碳水化合物 g", text: $carbs).keyboardType(.decimalPad)
                    TextField("脂肪 g", text: $fat).keyboardType(.decimalPad)
                    TextField("膳食纤维 g（可选）", text: $fiber).keyboardType(.decimalPad)
                }
                Section("日常计量单位") {
                    TextField("例如：瓶、片、袋", text: $unitName)
                    TextField("每单位重量 g / ml", text: $unitWeight).keyboardType(.decimalPad)
                }
            }
            .navigationTitle("添加包装食品")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { saveFood() }.fontWeight(.bold).disabled(name.trimmingCharacters(in: .whitespaces).isEmpty || Double(energy) == nil)
                }
            }
        }
        .tint(Color.fitGreen)
    }

    private func saveFood() {
        let basisWeight = basis == "serving" ? max(0.1, Double(serving) ?? 200) : 100
        let factor = 100 / basisWeight
        let rawEnergy = Double(energy) ?? 0
        let kcalPerBasis = energyUnit == "kJ" ? rawEnergy / 4.184 : rawEnergy
        let unit = unitName.trimmingCharacters(in: .whitespaces).isEmpty ? "份" : unitName
        let food = FoodItem(id: UUID().uuidString, name: name, category: category, emoji: "📦",
                            calories: kcalPerBasis * factor, protein: (Double(protein) ?? 0) * factor,
                            carbs: (Double(carbs) ?? 0) * factor, fat: (Double(fat) ?? 0) * factor,
                            fiber: (Double(fiber) ?? 0) * factor,
                            units: [FoodUnit(name: unit, grams: max(0.1, Double(unitWeight) ?? basisWeight)), FoodUnit(name: "克", grams: 1)],
                            defaultUnit: unit, source: "个人包装标签")
        store.addCustomFood(food)
        dismiss()
    }
}

struct WorkoutView: View {
    @EnvironmentObject private var store: AppStore
    @StateObject private var healthKit = HealthKitManager()
    @State private var name = ""
    @State private var kind = "力量训练"
    @State private var duration = "45"
    @State private var calories = ""
    @State private var sets = ""
    @State private var feeling = ""
    @State private var note = ""
    @State private var steps = ""
    @State private var activeCalories = ""
    @State private var water = ""
    @State private var sleep = ""
    @State private var hrv = ""
    @State private var stress = ""
    @State private var cycle = ""
    @State private var cycleExtra = ""
    @State private var healthNote = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("每一种努力都算数 🌿").font(.title2.bold())
                    Text("可以只写“今天练了肩背”，不用把每个动作都填完。").font(.caption).foregroundStyle(Color.fitMuted)
                }
                SoftCard(title: "🏋️ 记一次运动", subtitle: dayText(store.selectedDate)) {
                    VStack(spacing: 12) {
                        InputField(title: "运动 / 训练描述", placeholder: "例如：肩背训练、散步、普拉提", text: $name)
                        HStack {
                            Text("运动类型").font(.caption.weight(.semibold))
                            Spacer()
                            Picker("运动类型", selection: $kind) {
                                ForEach(["力量训练", "有氧运动", "散步 / 徒步", "瑜伽 / 拉伸", "球类运动", "其他"], id: \.self) { Text($0) }
                            }.labelsHidden()
                        }
                        HStack(spacing: 10) {
                            InputField(title: "时长（分钟）", placeholder: "45", text: $duration, numeric: true)
                            InputField(title: "消耗（kcal）", placeholder: "可留空", text: $calories, numeric: true)
                        }
                        InputField(title: "组数 / 轮数（可选）", placeholder: "例如：4 组", text: $sets)
                        HStack {
                            Text("训练感受").font(.caption.weight(.semibold))
                            Spacer()
                            Picker("训练感受", selection: $feeling) {
                                ForEach(["不填写", "轻松", "适中", "有挑战", "今天状态一般"], id: \.self) { Text($0) }
                            }.labelsHidden()
                        }
                        InputField(title: "动作 / 备注", placeholder: "高位下拉、坐姿划船、侧平举……", text: $note, axis: .vertical)
                        Button(action: saveWorkout) {
                            Label("保存运动记录", systemImage: "checkmark.circle.fill").frame(maxWidth: .infinity)
                        }.buttonStyle(.borderedProminent).tint(Color.fitGreen).disabled(name.trimmingCharacters(in: .whitespaces).isEmpty || Int(duration) == nil)
                    }
                }

                SoftCard(title: "⌚ Apple 健康同步", subtitle: "在 iPhone 上授权后，可读取支持的步数、活动能量、睡眠和 HRV 数据。") {
                    Button {
                        Task {
                            if let result = await healthKit.sync(for: store.selectedDate) {
                                var merged = store.health(on: store.selectedDate)
                                merged.steps = result.steps ?? merged.steps
                                merged.activeCalories = result.activeCalories ?? merged.activeCalories
                                merged.sleepHours = result.sleepHours ?? merged.sleepHours
                                merged.hrv = result.hrv ?? merged.hrv
                                store.saveHealth(merged, for: store.selectedDate)
                            }
                        }
                    } label: {
                        if healthKit.isSyncing {
                            ProgressView().tint(.white)
                        } else {
                            Label("请求授权并同步", systemImage: "heart.text.square.fill")
                        }
                    }
                    .buttonStyle(.borderedProminent).tint(Color.fitGreen).disabled(healthKit.isSyncing || !healthKit.isAvailable)
                    Text(healthKit.statusMessage).font(.caption).foregroundStyle(Color.fitMuted)
                    Text("压力感受目前需要手动记录；Apple 健康并不提供通用的实时压力指标。生理周期阶段也保留手动记录。")
                        .font(.caption2).foregroundStyle(Color.fitMuted)
                }

                SoftCard(title: "🌤️ 今日活动与恢复", subtitle: "手动补充或修改同步的数据。") {
                    VStack(spacing: 12) {
                        HStack(spacing: 10) {
                            InputField(title: "步数", placeholder: "8500", text: $steps, numeric: true)
                            InputField(title: "活动能量 kcal", placeholder: "可选", text: $activeCalories, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "饮水 ml", placeholder: "2000", text: $water, numeric: true)
                            InputField(title: "睡眠小时", placeholder: "7.5", text: $sleep, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "HRV ms", placeholder: "48", text: $hrv, numeric: true)
                            VStack(alignment: .leading, spacing: 5) {
                                Text("主观压力").font(.caption.weight(.semibold))
                                Picker("主观压力", selection: $stress) {
                                    Text("未记录").tag("")
                                    Text("1 · 放松").tag("1")
                                    Text("2 · 轻松").tag("2")
                                    Text("3 · 一般").tag("3")
                                    Text("4 · 有点压力").tag("4")
                                    Text("5 · 压力较大").tag("5")
                                }.labelsHidden().frame(maxWidth: .infinity)
                            }
                        }
                        HStack(spacing: 10) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text("生理周期").font(.caption.weight(.semibold))
                                Picker("生理周期", selection: $cycle) {
                                    Text("未记录").tag("")
                                    Text("经期").tag("经期")
                                    Text("卵泡期").tag("卵泡期")
                                    Text("排卵期").tag("排卵期")
                                    Text("黄体期 / 经前").tag("黄体期 / 经前")
                                }.labelsHidden().frame(maxWidth: .infinity)
                            }
                            InputField(title: "周期补偿 kcal", placeholder: "可选", text: $cycleExtra, numeric: true)
                        }
                        InputField(title: "今日感受 / 备注", placeholder: "精神不错、昨晚睡得比较晚……", text: $healthNote, axis: .vertical)
                        Button(action: saveHealth) {
                            Label("保存今日状态", systemImage: "heart.fill").frame(maxWidth: .infinity)
                        }.buttonStyle(.borderedProminent).tint(Color.fitGreen)
                    }
                }

                SoftCard(title: "📝 \(dayText(store.selectedDate)) 运动日记", subtitle: "运动消耗仅在有明确记录时显示。") {
                    let logs = store.workouts(on: store.selectedDate).reversed()
                    if logs.isEmpty {
                        EmptyHint(emoji: "🌿", text: "今天还没有运动记录。休息也是训练计划的一部分。")
                    } else {
                        ForEach(Array(logs)) { log in
                            HStack(alignment: .top, spacing: 10) {
                                Text("🏋️").font(.title2).frame(width: 42, height: 42).background(Color.fitMint, in: RoundedRectangle(cornerRadius: 13))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(log.name).font(.subheadline.weight(.semibold))
                                    Text("\(log.kind) · \(log.duration) 分钟\(log.sets.isEmpty ? "" : " · \(log.sets)")").font(.caption).foregroundStyle(Color.fitMuted)
                                    if !log.note.isEmpty { Text(log.note).font(.caption2).foregroundStyle(Color.fitMuted) }
                                }
                                Spacer()
                                VStack(alignment: .trailing, spacing: 5) {
                                    Text(log.calories.map { "\(kcal($0)) kcal" } ?? "未填写").font(.caption.weight(.semibold))
                                    Button(role: .destructive) { store.deleteWorkout(log.id) } label: { Image(systemName: "trash").font(.caption) }
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .padding(16)
        }
        .background(Color.fitCream.ignoresSafeArea())
        .navigationTitle("运动与恢复")
        .onAppear(perform: loadHealth)
        .onChange(of: store.selectedDate) { _, _ in loadHealth() }
    }

    private func saveWorkout() {
        let log = WorkoutLog(date: store.selectedDate, name: name.trimmingCharacters(in: .whitespaces),
                             kind: kind, duration: max(1, Int(duration) ?? 1),
                             calories: calories.isEmpty ? nil : Double(calories),
                             sets: sets, feeling: feeling == "不填写" ? "" : feeling, note: note)
        store.addWorkout(log)
        name = ""; duration = "45"; calories = ""; sets = ""; feeling = ""; note = ""
    }

    private func loadHealth() {
        let h = store.health(on: store.selectedDate)
        steps = h.steps.map { String($0) } ?? ""
        activeCalories = h.activeCalories.map { String(Int($0.rounded())) } ?? ""
        water = h.waterML.map { String($0) } ?? ""
        sleep = h.sleepHours.map { String(format: "%.1f", $0) } ?? ""
        hrv = h.hrv.map { String(format: "%.1f", $0) } ?? ""
        stress = h.stress.map { String($0) } ?? ""
        cycle = h.cycle
        cycleExtra = h.cycleExtra.map { String(Int($0)) } ?? ""
        healthNote = h.note
    }

    private func saveHealth() {
        let h = HealthDay(steps: Int(steps), activeCalories: Double(activeCalories), waterML: Int(water),
                          sleepHours: Double(sleep), hrv: Double(hrv), stress: Int(stress),
                          cycle: cycle, cycleExtra: Double(cycleExtra), note: healthNote)
        store.saveHealth(h, for: store.selectedDate)
    }
}

struct InputField: View {
    var title: String
    var placeholder: String
    @Binding var text: String
    var numeric: Bool = false
    var axis: Axis = .horizontal

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption.weight(.semibold)).foregroundStyle(Color.fitInk)
            Group {
                if axis == .vertical {
                    TextField(placeholder, text: $text, axis: .vertical).lineLimit(2...4)
                } else {
                    TextField(placeholder, text: $text)
                        .keyboardType(numeric ? .decimalPad : .default)
                }
            }
            .padding(11)
            .background(Color.fitCream, in: RoundedRectangle(cornerRadius: 12))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct CalendarView: View {
    @EnvironmentObject private var store: AppStore
    @State private var month = Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Date())) ?? Date()

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 7)
    private var days: [Date] {
        let calendar = Calendar.current
        let first = calendar.date(from: calendar.dateComponents([.year, .month], from: month)) ?? month
        let weekday = (calendar.component(.weekday, from: first) + 5) % 7
        let start = calendar.date(byAdding: .day, value: -weekday, to: first) ?? first
        return (0..<42).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("给每一天一个小小的回顾 🌼").font(.title2.bold())
                    Text("绿色代表还留有摄入预算，粉色代表超过目标。").font(.caption).foregroundStyle(Color.fitMuted)
                }
                SoftCard {
                    HStack {
                        Button { month = Calendar.current.date(byAdding: .month, value: -1, to: month) ?? month } label: {
                            Image(systemName: "chevron.left").padding(8)
                        }
                        Spacer()
                        Text(month.formatted(.dateTime.year().month())).font(.headline)
                        Spacer()
                        Button { month = Calendar.current.date(byAdding: .month, value: 1, to: month) ?? month } label: {
                            Image(systemName: "chevron.right").padding(8)
                        }
                        Button("本月") { month = Date() }.font(.caption.weight(.semibold))
                    }
                    .foregroundStyle(Color.fitGreen)
                    HStack {
                        ForEach(["一","二","三","四","五","六","日"], id: \.self) { d in
                            Text(d).font(.caption2.weight(.bold)).foregroundStyle(Color.fitMuted).frame(maxWidth: .infinity)
                        }
                    }
                    LazyVGrid(columns: columns, spacing: 5) {
                        ForEach(days, id: \.self) { date in
                            let isCurrentMonth = Calendar.current.isDate(date, equalTo: month, toGranularity: .month)
                            let balance = store.target(on: date) - store.calories(on: date)
                            let workouts = store.workouts(on: date)
                            Button { store.selectedDate = date } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(date.formatted(.dateTime.day())).font(.caption.weight(.bold))
                                        .frame(width: 22, height: 22)
                                        .background(Calendar.current.isDateInToday(date) ? Color.fitGreen : .clear, in: Circle())
                                        .foregroundStyle(Calendar.current.isDateInToday(date) ? .white : Color.fitInk)
                                    if store.calories(on: date) > 0 || !workouts.isEmpty {
                                        Text("\(balance >= 0 ? "余" : "超")\(kcal(abs(balance)))")
                                            .font(.system(size: 8, weight: .bold))
                                            .foregroundStyle(balance >= 0 ? Color.fitDarkGreen : Color(red: 0.70, green: 0.38, blue: 0.39))
                                            .lineLimit(1).minimumScaleFactor(0.6)
                                    } else {
                                        Text("·").font(.caption2).foregroundStyle(Color.fitMuted)
                                    }
                                    if let first = workouts.first {
                                        Text(first.name).font(.system(size: 7, weight: .medium)).lineLimit(1).foregroundStyle(Color.fitGreen)
                                    }
                                }
                                .frame(maxWidth: .infinity, minHeight: 57, alignment: .topLeading)
                                .padding(4)
                                .background(Calendar.current.isDate(date, inSameDayAs: store.selectedDate) ? Color.fitMint : .white,
                                            in: RoundedRectangle(cornerRadius: 10))
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Calendar.current.isDate(date, inSameDayAs: store.selectedDate) ? Color.fitGreen : Color.fitGreen.opacity(0.08), lineWidth: 1))
                                .opacity(isCurrentMonth ? 1 : 0.38)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    HStack(spacing: 12) {
                        Label("有剩余预算", systemImage: "circle.fill").foregroundStyle(Color.fitGreen)
                        Label("超过目标", systemImage: "circle.fill").foregroundStyle(Color.pink)
                    }.font(.caption2)
                }

                SoftCard(title: "🌷 \(dayText(store.selectedDate)) 的小结", subtitle: "点击上面的日期查看对应记录。") {
                    SummaryLine(title: "实际摄入", value: "\(kcal(store.calories(on: store.selectedDate))) kcal")
                    let balance = store.target(on: store.selectedDate) - store.calories(on: store.selectedDate)
                    SummaryLine(title: balance >= 0 ? "剩余摄入预算" : "超过目标", value: "\(kcal(abs(balance))) kcal")
                    SummaryLine(title: "当日目标", value: "\(kcal(store.target(on: store.selectedDate))) kcal")
                    SummaryLine(title: "运动消耗记录", value: "\(kcal(store.workoutCalories(on: store.selectedDate))) kcal")
                    SummaryLine(title: "运动摘要", value: store.workouts(on: store.selectedDate).map(\.name).joined(separator: "、").isEmpty ? "无运动记录" : store.workouts(on: store.selectedDate).map(\.name).joined(separator: "、"))
                    let h = store.health(on: store.selectedDate)
                    SummaryLine(title: "步数 / 睡眠", value: "\(h.steps.map { $0.formatted() + " 步" } ?? "—") / \(h.sleepHours.map { String(format: "%.1f 小时", $0) } ?? "—")")
                }
            }
            .padding(16)
        }
        .background(Color.fitCream.ignoresSafeArea())
        .navigationTitle("月历")
    }
}

struct SummaryLine: View {
    var title: String
    var value: String
    var body: some View {
        HStack(alignment: .top) {
            Text(title).font(.caption).foregroundStyle(Color.fitMuted)
            Spacer(minLength: 10)
            Text(value).font(.caption.weight(.semibold)).multilineTextAlignment(.trailing)
        }
        .padding(.vertical, 5)
    }
}

struct ProfileView: View {
    @EnvironmentObject private var store: AppStore
    @State private var goalType = "lose"
    @State private var targetMode = "manual"
    @State private var manualCalories = "1800"
    @State private var protein = "120"
    @State private var carbs = "200"
    @State private var fat = "60"
    @State private var water = "2000"
    @State private var deficit = "300"
    @State private var surplus = "200"
    @State private var cycleAdjust = false
    @State private var cycleExtra = "0"
    @State private var nickname = ""
    @State private var sex = ""
    @State private var age = ""
    @State private var height = ""
    @State private var weight = ""
    @State private var activityFactor = "1.375"
    @State private var energyMode = "factor"
    @State private var bodyWeight = ""
    @State private var bodyFat = ""
    @State private var waist = ""
    @State private var hip = ""
    @State private var chest = ""
    @State private var thigh = ""
    @State private var arm = ""
    @State private var calf = ""
    @State private var bodyNote = ""
    @State private var showImporter = false
    @State private var shareURL: URL?
    @State private var alertMessage = ""
    @State private var showAlert = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("用适合自己的节奏前进 💗").font(.title2.bold())
                    Text("身体数据是观察工具，不是对自己的评价。").font(.caption).foregroundStyle(Color.fitMuted)
                }

                SoftCard(title: "🎯 我的目标", subtitle: "可以随时调整目标与营养参考值。") {
                    VStack(spacing: 12) {
                        Picker("目标", selection: $goalType) {
                            Text("减脂").tag("lose")
                            Text("增肌").tag("gain")
                            Text("维持").tag("maintain")
                        }.pickerStyle(.segmented)
                        Picker("目标热量模式", selection: $targetMode) {
                            Text("手动目标").tag("manual")
                            Text("根据 TDEE 估算").tag("calculated")
                        }.pickerStyle(.segmented)
                        InputField(title: "手动目标 kcal", placeholder: "1800", text: $manualCalories, numeric: true)
                        HStack(spacing: 10) {
                            InputField(title: "蛋白质 g", placeholder: "120", text: $protein, numeric: true)
                            InputField(title: "碳水 g", placeholder: "200", text: $carbs, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "脂肪 g", placeholder: "60", text: $fat, numeric: true)
                            InputField(title: "饮水参考 ml", placeholder: "2000", text: $water, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "减脂差额 kcal", placeholder: "300", text: $deficit, numeric: true)
                            InputField(title: "增肌差额 kcal", placeholder: "200", text: $surplus, numeric: true)
                        }
                        Toggle("启用生理周期热量补偿", isOn: $cycleAdjust).tint(Color.fitGreen)
                        InputField(title: "默认周期补偿 kcal / 天", placeholder: "0", text: $cycleExtra, numeric: true)
                        Button("保存目标设置", action: saveGoals).buttonStyle(.borderedProminent).tint(Color.fitGreen).frame(maxWidth: .infinity)
                    }
                }

                SoftCard(title: "🪞 身体档案", subtitle: "基础代谢是公式估算值，并非 Apple Watch 直接测量值。") {
                    VStack(spacing: 12) {
                        InputField(title: "昵称（可选）", placeholder: "喜欢的称呼", text: $nickname)
                        Picker("用于 BMR 估算的公式参数", selection: $sex) {
                            Text("暂不指定").tag("")
                            Text("女性公式").tag("female")
                            Text("男性公式").tag("male")
                        }
                        HStack(spacing: 10) {
                            InputField(title: "年龄", placeholder: "岁", text: $age, numeric: true)
                            InputField(title: "身高", placeholder: "cm", text: $height, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "当前体重", placeholder: "kg", text: $weight, numeric: true)
                            VStack(alignment: .leading, spacing: 5) {
                                Text("活动系数").font(.caption.weight(.semibold))
                                Picker("活动系数", selection: $activityFactor) {
                                    Text("1.20 久坐").tag("1.2")
                                    Text("1.375 轻度").tag("1.375")
                                    Text("1.55 中等").tag("1.55")
                                    Text("1.725 高活动").tag("1.725")
                                    Text("1.90 很高").tag("1.9")
                                }.labelsHidden()
                            }
                        }
                        Picker("TDEE 估算方式", selection: $energyMode) {
                            Text("BMR × 活动系数").tag("factor")
                            Text("BMR × 1.2 + 活动能量").tag("dynamic")
                        }
                        let bmrValue = store.bmrPreview(sex: sex, age: Double(age), height: Double(height), weight: Double(weight))
                        VStack(alignment: .leading, spacing: 7) {
                            SummaryLine(title: "BMR 估算", value: bmrValue.map { "\(kcal($0)) kcal" } ?? "填写完整资料后计算")
                            SummaryLine(title: "基础 TDEE", value: bmrValue.map { "\(kcal($0 * (energyMode == "dynamic" ? 1.2 : (Double(activityFactor) ?? 1.375))) ) kcal" } ?? "—")
                            SummaryLine(title: "当前每日目标", value: "\(kcal(previewTarget(bmr: bmrValue))) kcal")
                        }
                        .padding(12).background(Color.fitCream, in: RoundedRectangle(cornerRadius: 14))
                        Button("保存身体档案", action: saveProfile).buttonStyle(.borderedProminent).tint(Color.fitGreen).frame(maxWidth: .infinity)
                    }
                }

                SoftCard(title: "📏 记录身体维度", subtitle: "体重、体脂率、腰围、臀围等可以按日期保存。") {
                    VStack(spacing: 12) {
                        HStack(spacing: 10) {
                            InputField(title: "体重 kg", placeholder: "可选", text: $bodyWeight, numeric: true)
                            InputField(title: "体脂率 %", placeholder: "可选", text: $bodyFat, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "腰围 cm", placeholder: "可选", text: $waist, numeric: true)
                            InputField(title: "臀围 cm", placeholder: "可选", text: $hip, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "胸围 cm", placeholder: "可选", text: $chest, numeric: true)
                            InputField(title: "大腿围 cm", placeholder: "可选", text: $thigh, numeric: true)
                        }
                        HStack(spacing: 10) {
                            InputField(title: "上臂围 cm", placeholder: "可选", text: $arm, numeric: true)
                            InputField(title: "小腿围 cm", placeholder: "可选", text: $calf, numeric: true)
                        }
                        InputField(title: "备注", placeholder: "例如：晨起测量", text: $bodyNote)
                        Button("保存身体记录", action: saveBody).buttonStyle(.borderedProminent).tint(Color.fitGreen).frame(maxWidth: .infinity)
                    }
                    if !store.data.bodyLogs.isEmpty {
                        Divider()
                        ForEach(store.data.bodyLogs.sorted { $0.date > $1.date }.prefix(10)) { log in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(dayText(log.date)).font(.caption.weight(.bold))
                                    Spacer()
                                    Button(role: .destructive) { store.deleteBodyLog(log.id) } label: { Image(systemName: "trash").font(.caption) }
                                }
                                Text(log.measurements.map { "\($0.key) \($0.value.formatted(.number.precision(.fractionLength(0...1))))" }.sorted().joined(separator: " · "))
                                    .font(.caption2).foregroundStyle(Color.fitMuted)
                                if !log.note.isEmpty { Text(log.note).font(.caption2).foregroundStyle(Color.fitMuted) }
                            }.padding(.vertical, 4)
                        }
                    }
                }

                SoftCard(title: "🧳 数据备份与恢复", subtitle: "数据保存在本机 App 沙盒，不会自动上传服务器。") {
                    Button {
                        shareURL = store.exportBackup()
                        if shareURL == nil { alertMessage = "导出失败，请稍后重试。"; showAlert = true }
                    } label: { Label("导出全部数据 JSON", systemImage: "square.and.arrow.up") }
                        .buttonStyle(.borderedProminent).tint(Color.fitGreen)
                    if let shareURL {
                        ShareLink(item: shareURL) { Label("分享 / 保存备份文件", systemImage: "doc.zipper") }
                            .font(.subheadline.weight(.semibold))
                    }
                    Button { showImporter = true } label: { Label("导入 JSON 备份", systemImage: "square.and.arrow.down") }
                        .buttonStyle(.bordered)
                    Button(role: .destructive) {
                        store.clearAllData()
                        loadSettings()
                        alertMessage = "本机记录已清空。"; showAlert = true
                    } label: { Label("清空全部本地数据", systemImage: "trash") }
                    Text("导入备份会替换当前记录；请先导出当前数据。").font(.caption2).foregroundStyle(Color.fitMuted)
                }
            }
            .padding(16)
        }
        .background(Color.fitCream.ignoresSafeArea())
        .navigationTitle("我的")
        .onAppear(perform: loadSettings)
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json], allowsMultipleSelection: false) { result in
            do {
                let url = try result.get().first!
                let secured = url.startAccessingSecurityScopedResource()
                defer { if secured { url.stopAccessingSecurityScopedResource() } }
                try store.importBackup(from: url)
                loadSettings()
                alertMessage = "备份导入成功。"
            } catch {
                alertMessage = "导入失败，请确认这是 FitNote 导出的 JSON 文件。"
            }
            showAlert = true
        }
        .alert("FitNote", isPresented: $showAlert) { Button("好", role: .cancel) {} } message: { Text(alertMessage) }
    }

    private func loadSettings() {
        let g = store.data.goals
        goalType = g.goalType; targetMode = g.targetMode
        manualCalories = String(Int(g.manualCalories)); protein = String(Int(g.protein))
        carbs = String(Int(g.carbs)); fat = String(Int(g.fat)); water = String(Int(g.waterML))
        deficit = String(Int(g.deficit)); surplus = String(Int(g.surplus))
        cycleAdjust = g.cycleAdjustEnabled; cycleExtra = String(Int(g.cycleDefaultExtra))
        let p = store.data.profile
        nickname = p.nickname; sex = p.sex; age = p.age.map { String($0) } ?? ""
        height = p.heightCM.map { String($0) } ?? ""; weight = p.weightKG.map { String($0) } ?? ""
        activityFactor = String(p.activityFactor); energyMode = p.energyMode
    }

    private func saveGoals() {
        store.saveGoals(Goals(goalType: goalType, targetMode: targetMode, manualCalories: Double(manualCalories) ?? 1800,
                              protein: Double(protein) ?? 120, carbs: Double(carbs) ?? 200, fat: Double(fat) ?? 60,
                              waterML: Double(water) ?? 2000, deficit: Double(deficit) ?? 300,
                              surplus: Double(surplus) ?? 200, cycleAdjustEnabled: cycleAdjust,
                              cycleDefaultExtra: Double(cycleExtra) ?? 0))
    }

    private func saveProfile() {
        store.saveProfile(UserProfile(nickname: nickname, sex: sex, age: Double(age), heightCM: Double(height),
                                      weightKG: Double(weight), activityFactor: Double(activityFactor) ?? 1.375,
                                      energyMode: energyMode))
    }

    private func previewTarget(bmr: Double?) -> Double {
        guard targetMode == "calculated", let bmr else { return Double(manualCalories) ?? 1800 }
        let tdee = bmr * (energyMode == "dynamic" ? 1.2 : (Double(activityFactor) ?? 1.375))
        switch goalType {
        case "lose": return tdee - (Double(deficit) ?? 300)
        case "gain": return tdee + (Double(surplus) ?? 200)
        default: return tdee
        }
    }

    private func saveBody() {
        var measurements: [String: Double] = [:]
        let fields: [(String, String)] = [("体重", bodyWeight), ("体脂率", bodyFat), ("腰围", waist),
                                          ("臀围", hip), ("胸围", chest), ("大腿围", thigh),
                                          ("上臂围", arm), ("小腿围", calf)]
        for (key, value) in fields {
            if let number = Double(value), number >= 0 { measurements[key] = number }
        }
        guard !measurements.isEmpty else { alertMessage = "请至少填写一项身体数据。"; showAlert = true; return }
        store.addBodyLog(BodyLog(date: store.selectedDate, measurements: measurements, note: bodyNote))
        bodyWeight = ""; bodyFat = ""; waist = ""; hip = ""; chest = ""; thigh = ""; arm = ""; calf = ""; bodyNote = ""
    }
}

extension AppStore {
    func bmrPreview(sex: String, age: Double?, height: Double?, weight: Double?) -> Double? {
        guard let age, let height, let weight, !sex.isEmpty else { return nil }
        return 10 * weight + 6.25 * height - 5 * age + (sex == "male" ? 5 : -161)
    }
}
