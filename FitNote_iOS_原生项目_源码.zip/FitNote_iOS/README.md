# FitNote 原生 iPhone App（开发起始版）

这是 FitNote 的 SwiftUI 原生项目起始版，目标 iOS 17+。包含：
- 可爱豹宝图标（花朵 + 粉色哑铃）
- 首页、饮食、运动、月历、我的五个主页面
- 常见食物参考库与按“个 / 碗 / 片”等日常单位录入
- 包装食品营养标签手动录入（支持 kJ/kcal、每 100 g 或每份）
- 饮食记录、运动日记、身体围度、饮水、步数、睡眠、HRV、压力感受和生理周期记录
- 本地 JSON 持久化、导出与导入备份
- HealthKit 读取授权和步数、活动能量、睡眠、HRV 同步代码

## 如何打开
1. 将 `FitNote_iOS.zip` 解压。
2. 在 Mac 上安装 Xcode 15 或更新版本。
3. 双击 `FitNote.xcodeproj`。
4. 在 Xcode 的 Signing & Capabilities 中选择你自己的 Apple Developer Team。Bundle Identifier `com.example.FitNote` 也建议改成唯一值。
5. 在真实 iPhone 上运行。HealthKit 数据读取需设备支持、Apple 健康中有相应数据并由用户授权。

## 当前限制
- 这是可继续开发的源码工程，并非已签名的安装包；本环境没有 macOS/Xcode，无法在这里编译、签名或直接安装到 iPhone。
- Apple Watch 数据通过 iPhone 的 HealthKit 读取；当前读取步数、活动能量、睡眠和 HRV。实际可读数据取决于设备、授权和健康记录。
- Apple 健康没有一个通用的“实时压力”字段，压力感受目前由用户手动记录。
- 生理周期阶段目前手动记录；未调用 GPT API 或任何付费 AI 服务。
- 内置食物营养值为常见食物参考数据，不是完整官方数据库；包装食品应优先依据实际标签。
- 当前版本在设备本地保存数据，不自动云同步。请定期导出 JSON 备份。

## 项目结构
- `FitNote/FitNoteApp.swift` — App 入口
- `FitNote/Models.swift` — 数据模型与食物库
- `FitNote/AppStore.swift` — 本地数据存储、能量估算和备份
- `FitNote/HealthKitManager.swift` — Apple HealthKit 读取
- `FitNote/ContentView.swift` — SwiftUI 页面与交互
- `FitNote/Assets.xcassets` — 豹宝图标资源


补充：本次更新已将用户提供的小豹子图标替换为 App 图标资源，并在饮食餐次中加入“零食 / 大餐”选项。